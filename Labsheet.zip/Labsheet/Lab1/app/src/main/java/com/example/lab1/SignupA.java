package com.example.lab1;
import android.app.Activity;
import android.os.Bundle;

public class SignupA extends Activity {
    protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.signupa);
    }

}
